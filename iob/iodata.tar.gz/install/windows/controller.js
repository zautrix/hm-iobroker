'use strict';
require(__dirname + '/node_modules/iobroker.js-controller/controller.js');